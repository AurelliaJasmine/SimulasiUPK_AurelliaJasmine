package com.example.simulasiupk_aurelliajasmine

data class DataBBI (
    var nama  : String,
    var tbBdn : String,
    var hasil : String,
)